import sys
import xbmc,xbmcaddon,xbmcvfs,xbmcgui
import os
import stat

menuItems = ["o----o     Vavoo Live EPG", "o----------------------------------------o", "o----o     Alternativen", "o----------------------------------------o"]
select = xbmcgui.Dialog().select('o~~~~~ Live TV Auswahl ~~~~~o', menuItems)
select
if select == 0:
	xbmc.executebuiltin('ActivateWindow(TVGuide,pvr://channels/tv/pvr.iptvsimple)')
elif select == 2:
	xbmc.executebuiltin('RunAddon("plugin.video.vatv")')