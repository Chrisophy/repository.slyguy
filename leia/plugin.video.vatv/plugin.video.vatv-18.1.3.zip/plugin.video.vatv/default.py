#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmcaddon,xbmcplugin,xbmcgui,urllib,sys,re,os

addon = xbmcaddon.Addon()
pluginhandle = int(sys.argv[1])
addonID = addon.getAddonInfo('id')
icon1=xbmc.translatePath('special://home/addons/'+addonID+'/vavoo.png')
icon2=xbmc.translatePath('special://home/addons/'+addonID+'/iptv.png')
icon3=xbmc.translatePath('special://home/addons/'+addonID+'/simply.png')
icon4=xbmc.translatePath('special://home/addons/'+addonID+'/update.png')
icon5=xbmc.translatePath('special://home/addons/'+addonID+'/tvtap.png')



def index():
    addDir("VAVOO","plugin://plugin.video.vavooto/?action=channels",icon1)
    addDir("IPTV","plugin://plugin.video.iptv.free",icon2)
    addDir("SIMPLY TV","plugin://plugin.video.simplytv",icon3)
    addDir("SIMPLY UPDATE","plugin://plugin.video.simupdate",icon4)    
    addDir("TV TAP","plugin://script.module.7of9-live",icon5)


    xbmcplugin.endOfDirectory(pluginhandle)
    
    
    
def addDir(name,url,iconimage):
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('fanart_image',iconimage)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)
    return ok


def translation(id):
    return addon.getLocalizedString(id).encode('utf-8')


def parameters_string_to_dict(parameters):
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

index()
